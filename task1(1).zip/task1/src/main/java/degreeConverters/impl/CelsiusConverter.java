package degreeConverters.impl;

import degreeConverters.IDegreeConverter;

public class CelsiusConverter implements IDegreeConverter {
//    private static final String DEGREE_TYPE = "C";

    @Override
    public double calculateCelsiusDegree(double degree) {
        return degree;
    }

    @Override
    public long convertFromCelsius(double celsiusDegree) {
        return Math.round(celsiusDegree);
    }

    @Override
    public String getType() {
        return /*DEGREE_TYPE*/ "C";
    }
}
