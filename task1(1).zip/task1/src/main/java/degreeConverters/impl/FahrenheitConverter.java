package degreeConverters.impl;

import degreeConverters.IDegreeConverter;

public class FahrenheitConverter implements IDegreeConverter {
//    private static final String DEGREE_TYPE = "F";

    @Override
    public double calculateCelsiusDegree(double degree) {
        return (degree - 32)* 5 / 9;
    }

    @Override
    public long convertFromCelsius(double celsiusDegree) {
        return Math.round(celsiusDegree * 9 / 5 + 32);
    }

    @Override
    public String getType() {
        return /*DEGREE_TYPE*/ "F";
    }
}
