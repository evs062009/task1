package degreeConverters.impl;

import degreeConverters.IDegreeConverter;

public class KelvinConverter implements IDegreeConverter {
//    private static final String DEGREE_TYPE = "K";

    @Override
    public double calculateCelsiusDegree(double degree) {
        return degree - 273.15;
    }

    @Override
    public long convertFromCelsius(double celsiusDegree) {
        return Math.round(celsiusDegree + 273.15);
    }

    @Override
    public String getType() {
        return /*DEGREE_TYPE*/ "K";
    }
}
