package degreeConverters;

import java.security.InvalidParameterException;

public interface IDegreeConverter {

    default double convertToCelsius(String inputDegree) throws InvalidParameterException {
        double degree;
        String substring = inputDegree.substring(0, inputDegree.length() - getType().length());
        try {
            degree = Double.parseDouble(substring);
        } catch (NumberFormatException ex) {
            throw new InvalidParameterException();
        }
        return calculateCelsiusDegree(degree);
    }

    double calculateCelsiusDegree(double degree);

    long convertFromCelsius(double celsiusDegree);

    String getType();
}
