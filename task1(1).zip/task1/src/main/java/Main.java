import degreeConverters.IDegreeConverter;
import degreeConverters.impl.CelsiusConverter;
import degreeConverters.impl.FahrenheitConverter;
import degreeConverters.impl.KelvinConverter;

import java.security.InvalidParameterException;

public class Main {

    public static void main(String[] args) {
        App app = new App();
        IDegreeConverter[] converters = {new CelsiusConverter(), new KelvinConverter(), new FahrenheitConverter()};
        try {
            System.out.println(app.execute("299K", converters));
        } catch (InvalidParameterException ex) {
            System.out.println("invalod parameter");
        }
    }
}
