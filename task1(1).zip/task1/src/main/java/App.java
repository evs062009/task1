import degreeConverters.IDegreeConverter;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;

public class App {

    public String execute(String inputDegree, IDegreeConverter... converters) throws InvalidParameterException {
        IntermediateResult intermediateResult = convertToCelsius(inputDegree, converters);
        return createResult(intermediateResult, converters);
    }

    private IntermediateResult convertToCelsius(String inputDegree, IDegreeConverter[] converters)
            throws InvalidParameterException {
        for (IDegreeConverter converter : converters) {
            String degreeType = converter.getType();
            if (inputDegree.endsWith(degreeType)) {
                return new IntermediateResult(degreeType, converter.convertToCelsius(inputDegree));
            }
        }
        throw new InvalidParameterException();
    }

    private String createResult(IntermediateResult intermediateResult, IDegreeConverter[] converters) {
        List<String> result = new ArrayList<>();
        String degreeType;
        for (IDegreeConverter converter : converters) {
            degreeType = converter.getType();
            if (!degreeType.equals(intermediateResult.InputDegreeType)) {
                result.add(degreeType + ": " + converter.convertFromCelsius(intermediateResult.celsiusDegree));
            }
        }
        return result.toString();
    }

    private class IntermediateResult {
        private String InputDegreeType;
        private double celsiusDegree;

        private IntermediateResult(String inputDegreeType, double celsiusDegree) {
            InputDegreeType = inputDegreeType;
            this.celsiusDegree = celsiusDegree;
        }
    }
}
